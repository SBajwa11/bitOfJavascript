function half() {
    var initialnumber = prompt("Please enter a value", "0");
    var number = parseFloat(initialnumber);
    var halvednumber = number/2;
    
    document.getElementById('initialvalue').innerHTML = 'The number entered is: ' + initialnumber;
    document.getElementById('finalvalue').innerHTML = 'The number once halved is: ' + halvednumber;
}

function multiply() {
    var first = prompt("Please enter the first number", "0");
    var number = parseFloat(first);
    var second = prompt("Please enter the second number", "0");
    var secondnumber = parseFloat(second);
    var final = (number * secondnumber) + 3;
    
    document.getElementById('first').innerHTML = 'The first number entered is: ' + first;
    document.getElementById('second').innerHTML = 'The second number entered is: ' + second;
    document.getElementById('third').innerHTML = 'The result once multiplied and increased by 3 is: ' + final;
}

function timesintoten() {
    let x = 1000;
    let n = 0;
    
    while (x > 10) {
        x = x/2;
        n++;
    }
    
    document.getElementById('count').innerHTML = 'The number of times 1000 can be halved until it is below 10 is: ' + n;
}

function filterarray() {
    var inputArray = [];
    var size = prompt('Enter the size of the array:');
    var arraysize = parseInt(size);
    
    for (var i=0; i<arraysize; i++) {
        inputArray[i] = prompt('Enter number ' + (i+1));
    }
    
    document.getElementById('array').innerHTML = 'The array is ' + inputArray;
    document.getElementById('filteredarray').innerHTML = 'The array once filtered to omit values above 10 is: ' + inputArray.filter(x => 10 >= x);
    
}

function clear () {
    document.getElementById('count').innerHTML = ""; 
} // could not get function to work which would allow for the text to clear (removed button which i had initially put in)